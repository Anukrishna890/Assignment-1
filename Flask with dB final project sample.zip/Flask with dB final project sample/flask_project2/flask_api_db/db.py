import pymysql

def get_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',  # Default XAMPP password
        database='flask_db',
        cursorclass=pymysql.cursors.DictCursor
    )
