# print('flask project')
# print('sample text')
from flask import Flask,render_template

app=Flask(__name__)

@app.route('/')
def index1():
    return render_template("index1.html")
    #return 'hello_world'

@app.route('/Motor_cycle',methods=['GET'])
def Motor_cycle():
    return render_template("Motor_cycle.html")
    #return 'Motor_cycle'

@app.route('/Locate_us',methods=['GET'])
def Locate_us():
    return render_template("Locate_us.html")
    #return 'Locate_us'

@app.route('/Accessories',methods=['GET'])
def Accessories():
    return render_template("Accessories.html")
    #return 'Accessories'

@app.route('/Support',methods=['GET'])
def Support():
    return render_template("Support.html")
    #return 'Support'

@app.route('/About_us',methods=['GET'])
def About_us():
    return render_template("About_us.html")
    #return 'About_us'

    
if __name__ == "__main__":
    app.run(debug=True)
    
    

